json:{
  "dont_grayscale": true
}